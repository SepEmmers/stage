<div class="footer">
    <p>&copy; Vandegaer</p>
    <p>#Succes!</p>
    <p>#JammerGeenFlexbox</p>
</div>