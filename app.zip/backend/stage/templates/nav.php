<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
<nav id="mySidenav" class="sidenav">
<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <a href="index.php">Home</a>
        <a href="nieuweInschrijving.php">Nieuwe inschrijving</a>
        <a href="nieuweSport.php">Nieuwe sport</a>
        <a href="overzicht.php">Overzicht inschrijvingen</a>
        <a href="ledenlijst.php">Ledenlijst</a>
        <a href="settings.php">Instellingen</a>
    </nav>
